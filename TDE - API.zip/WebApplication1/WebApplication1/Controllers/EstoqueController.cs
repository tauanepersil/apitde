﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using WebApplication1.e_mail;
using WebApplication1.models;


namespace WebApplication1.Controllers
{
    public class EstoqueController : Controller
    {
        [Route("api/[controller]")]
        [ApiController]
        public class EstoqueController : ControllerBase
        {
            private IList<Produto> ListaProdutos;

            public EstoqueController()
            {
                ListaProdutos = new List<Produto>();

                ListaProdutos.Add(new Produto()
                {
                    NomeProduto = "RedBull",
                    codigo = "0101",
                    descricaoProduto = "RedBull",
                    precoVendas = 9.00F,
                    precoCusto = 7.99F,
                    dataCadastro = new DateTime(2021, 08, 25),
                    estoque = 100,
                    imagem = "imagem1.png",
                    Altura = 0.2F,
                    Largura = 0.06F,
                    Profundidade = 0.250F,
                    categoriaProduto = "energetico",
                    Ativo = true

                });
            }

            [HttpPost("DebitarEstoque")]
            public ActionResult DebitarEstoque(debitarEstoque debitarEstoque)
            {
                var resultado = ListaProdutos.Where(P => P.codigo == debitarEstoque.codigo).FirstOrDefault();
                if (resultado == null)
                {
                    return NotFound("O produto não existe na base de dados");
                }

                if (debitarEstoque.qtde > resultado.EstoqueAtual)
                {
                    return BadRequest("O produto não tem estoque suficiente");
                }

                resultado.EstoqueAtual = resultado.EstoqueAtual - debitarEstoque.qtde;

                if (resultado.EstoqueAtual < resultado.EstoqueMinimo)
                {
                    using (System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient())
                    {
                        smtp.Host = "smtp.gmail.com";
                        smtp.Port = 587;
                        smtp.EnableSsl = true;
                        smtp.UseDefaultCredentials = false;
                        smtp.Credentials = new System.Net.NetworkCredential("germanodrp18@gamil.com", "SUASENHAdoEmail");
                    }

                    using (System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage())
                    {
                        mail.From = new System.Net.Mail.MailAddress("germanodrp18@gmail.com");
                        mail.To.Add(new System.Net.Mail.MailAddress("germanodrp18@gamil.com"));


                        mail.Subject = "estoque minimo";
                        mail.Body = "Olá, atenção. O estoque " + resultado.EstoqueAtual + " ta baixo!";
                    }
                }

                return Ok("Produto debitado do estoque com sucesso!");

            }
        }
    }
}
