﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using WebApplication1.e_mail;
using WebApplication1.models;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CadastroProdController : Controller
    { 

      private readonly IList<produto> listaProdutos;
        private readonly IEmailService _IEmailService;

        public CadastroProdController(IEmailService emailService)
        {
            _IEmailService = emailService;
            listaProdutos = new List<produto>();
            listaProdutos.Add(new produto()
            {
                codigo = 1,
                nome = "Monitor",
                precoCusto = 550,
                precoVenda = 650.40F,
                dataCadastro = new DateTime(2021, 8, 25),
                ativo = true,
                estoque = 10,
                imagem = "1.png",
                alturaCM = 25.4F,
                larguraCM = 30.4F,
                profundidadeCM = 3.7F,
                IDcategoria = 1,
            });
            listaProdutos.Add(new produto()
            {
                codigo = 2,
                nome = "Computador",
                precoCusto = 1500,
                precoVenda = 2300.50F,
                dataCadastro = new DateTime(2020, 5, 10),
                ativo = true,
                estoque = 14,
                imagem = "2.png",
                alturaCM = 40.2F,
                larguraCM = 21.5F,
                profundidadeCM = 10.8F,
                IDcategoria = 1,
            });
        }
           
        
        [HttpGet("CunsutaDeProd/{codigo}")]
         public ActionResult ObterPorcodigo(int codigo)
         {
                var resultadoProduto = listaProdutos.Where(p => p.codigo == codigo).FirstOrDefault();
                if (resultadoProduto == null) return BadRequest();
                return Ok(resultadoProduto);
          }
        [HttpPost("adiciona")]
        public ActionResult Adicionar([FromBody] produto produto)
        {
            var resultado = listaProdutos.Where(p => p.codigo == produto.codigo);
            if (resultado.Count() > 0)
            {
                return BadRequest("Cadastro não realizado, codigo já existe");
            }
            resultado = listaProdutos.Where(p => p.nome == produto.nome);
            if (resultado.Count() > 0)
            {
                return BadRequest("Cadastro não realizado, nome já existe");
            }
            listaProdutos.Add(produto);
            return Ok();
        }
        [HttpPut("atualizar/{codigo}")]
        public ActionResult atualizar(int codigo, [FromBody] produto produto)
        {
            var resultado = listaProdutos.Where(p => p.codigo == codigo).FirstOrDefault();
            if (resultado == null)
            {
                return NotFound("atualização não realizada, produto não existe");
            }
             resultado = listaProdutos.Where(p => p.nome == produto.nome).FirstOrDefault();
            if (resultado != null && resultado.codigo != codigo)
            {
                return BadRequest("Cadastro não realizado, nome já existe");
            }

            resultado = listaProdutos.Where(p => p.codigo == produto.codigo).FirstOrDefault();
            if (resultado != null && resultado.codigo != codigo)
            {
                return BadRequest("Cadastro não realizado, codigo já existe");
            }


            listaProdutos.Remove(resultado);
            listaProdutos.Add(produto);
            return Ok();
        }
        [HttpDelete("deleta/{codico}")]
        public ActionResult deleta(int codigo)
        {
            var resultado = listaProdutos.Where(p => p.codigo == codigo).FirstOrDefault();
            if (resultado == null)
            {
                return NotFound("Remoção não realizada, produto não existe");
            }
            listaProdutos.Remove(resultado);
            return Ok("produto removido com sucesso");
        }

        [HttpGet("CunsutaDeProdAtivo")]
        public ActionResult ObterPorAtivo()
        {
            var resultadoProduto = listaProdutos.Where(p => p.ativo == true);
            if (resultadoProduto.Count() == 0) return NotFound();
            return Ok(resultadoProduto);

        }
        [HttpGet("CunsutaDeProdInativo")]
        public ActionResult ObterPorInativo()
        {
            var resultadoProduto = listaProdutos.Where(p => p.ativo == false);
            if (resultadoProduto.Count() == 0) return BadRequest();
            return Ok(resultadoProduto);
        }


        [HttpGet("ObterPorcategoria/{categoria}")]
        public ActionResult ObterPorcategoria(int categoria)
        {
            var resultado = listaProdutos.Where(p => p.IDcategoria == categoria).FirstOrDefault();
            if (resultado == null) return BadRequest();
            return Ok(resultado);
        }
        
        [HttpPut("desativarProduto/{codigo}")]
        public ActionResult desativarProduto(int codigo,[FromBody] string motivo)
        {
            var resultado = listaProdutos.Where(p => p.codigo == codigo).FirstOrDefault();
            if (resultado == null)
            {
                return NotFound("Remoção não realizada, produto não existe");
            }
            resultado.ativo = false;
            resultado.dataDesativacao = DateTime.Now;
            resultado.motivoDesativacao =  motivo;
            listaProdutos.Remove(resultado);
            listaProdutos.Add(resultado);

            //enviar um email falando que o produto foi desativado.
            Mensagem mensagem = new Mensagem();
            mensagem.Assunto = "Desaivar produto - " + resultado.nome;
            mensagem.CorpoMensagem = @$"Olá, atenção produto {resultado.nome} foi desativado em {resultado.dataDesativacao} 
                                        pelo motivo {resultado.motivoDesativacao}
                                     ";
            mensagem.De = "";
            mensagem.Para = ""
                ;
                                
            if (resultado.ativo == false) {
                _IEmailService.Enviar(mensagem);
            }

            return Ok();
        }

    }
    }

