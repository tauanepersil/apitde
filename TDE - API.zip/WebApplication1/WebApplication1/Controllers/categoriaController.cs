﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebApplication1.models;

namespace WebApplication1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class categoriaController : Controller
    {
        private readonly IList<Categoria> listaCategoria;

        public categoriaController()
        {
            listaCategoria = new List<Categoria>();
            listaCategoria.Add(new Categoria()
            {
                IDcategoria = 1,
                descricaoCategoria = "eletronico",

            });
        }

        [HttpGet("CunsutaDeCategoria/{IDcategoria}")]
        public ActionResult ObterPorcodigo(int IDcategoria)
        {
            var resultadoCategoria = listaCategoria.Where(p => p.IDcategoria == IDcategoria).FirstOrDefault();
            if (resultadoCategoria == null) return BadRequest();
            return Ok(resultadoCategoria);
        }

        [HttpPost("adicionacategoria")]
            public ActionResult adicionacategoria([FromBody] Categoria categoria)
            {
                var resultado = listaCategoria.Where(p => p.IDcategoria == categoria.IDcategoria);
                if (resultado.Count() > 0)
                {
                    return BadRequest("Cadastro não realizado, categoria já existe");
                }
                listaCategoria.Add(categoria);
                return Ok();
            }

        [HttpPut("atualizarcateg/{IDcategoria}")]
        public ActionResult atualizarcateg(int IDcategoria, [FromBody] Categoria categoria)
        {
            var resultado = listaCategoria.Where(p => p.IDcategoria == IDcategoria).FirstOrDefault();
            if (resultado == null)
            {
                return NotFound("atualização não realizada, categoria não existe");
            }
            listaCategoria.Remove(resultado);
            listaCategoria.Add(categoria);
            return Ok();
        }

        [HttpDelete("deleta/{IDcategoria}")]
        public ActionResult deleta(int IDcategoria)
        {
            var resultado = listaCategoria.Where(p => p.IDcategoria == IDcategoria).FirstOrDefault();
            if (resultado == null)
            {
                return NotFound("Remoção não realizada, categoria não existe");
            }
            listaCategoria.Remove(resultado);
            return Ok("produto removido com sucesso");
        }

    }
}
