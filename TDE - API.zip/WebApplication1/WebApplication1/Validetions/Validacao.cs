﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FluentValidation;
using WebApplication1.models;

namespace WebApplication1.Validetions
{
    public class ProdutoValidation : AbstractValidator<produto>
    {
        public ProdutoValidation()
        {

            RuleFor(produto => produto.codigo)
                .NotEmpty().WithMessage("Campo codigo vazio, Tente novamente")
                .NotNull().WithMessage("Campo codigo não informado, Tente novamente")
                .GreaterThan(0).WithMessage("codigo tem ser maio que 0")

                ;

            RuleFor(produto => produto.nome)
                .NotEmpty().WithMessage("Campo nome vazio, Tente novamente")
                .NotNull().WithMessage("Campo nome não informado, Tente novamente")
                .MaximumLength(250).WithMessage("Tamanho maximo excedido de 250 caracteres, Tente novamente")
                .MinimumLength(3).WithMessage("Tamanho mininomo são 3 caracteres, Tente novamente")
                ;

            RuleFor(produto => produto.precoVenda)
                .NotEmpty().WithMessage("Campo preoço de venda vazio, Tente novamente")
                .NotNull().WithMessage("Campo preço de venda não informado, Tente novamente")
                .GreaterThanOrEqualTo(0).WithMessage("Preço de venda tem ser maior ou igual a 0")
            ;

            RuleFor(produto => produto.precoCusto)
                .NotEmpty().WithMessage("Campo preço de custo vazio, Tente novamente")
                .NotNull().WithMessage("Campo preço de custo não informado, Tente novamente")
                .GreaterThanOrEqualTo(0).WithMessage("Preço de venda tem ser maior ou igual a 0")
                
            ;
            RuleFor(produto => produto.dataCadastro)
                .NotEmpty().WithMessage("Campo data cadastro vazio, Tente novamente")
                .NotNull().WithMessage("Campo data cadastro não informado, Tente novamente")
               ;

            RuleFor(produto => produto.ativo)
                 .NotEmpty().WithMessage("Campo ativo vazio, Tente novamente")
                .NotNull().WithMessage("Campo ativo não informado, Tente novamente")
                ;

            RuleFor(produto => produto.estoque)
                .NotEmpty().WithMessage("Campo estoque vazio, Tente novamente")
                .NotNull().WithMessage("Campo estoque não informado, Tente novamente")
                .GreaterThanOrEqualTo(0).WithMessage("Estoque tem ser maior ou igual a 0")
                ;

            RuleFor(produto => produto.imagem)
                 .NotEmpty().WithMessage("Campo imagem vazio, Tente novamente")
                .NotNull().WithMessage("Campo imagem não informado, Tente novamente")
                ;

            RuleFor(produto => produto.IDcategoria)
                 .NotEmpty().WithMessage("Campo categoria vazio, Tente novamente")
                .NotNull().WithMessage("Campo categoria não informado, Tente novamente")
                ;
        }

    }
}
