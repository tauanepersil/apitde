﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FluentValidation;
using WebApplication1.models;

namespace WebApplication1.Validetions
{
    public class validacaoCategoria : AbstractValidator<Categoria>

    {
        public validacaoCategoria() {

            RuleFor(Categoria => Categoria.IDcategoria)
                .NotEmpty().WithMessage("Campo categoria vazio, Tente novamente")
                .NotNull().WithMessage("Campo categoria não informado, Tente novamente")
                ;

            RuleFor(Categoria => Categoria.descricaoCategoria)
                 .NotEmpty().WithMessage("Campo descrição vazio, Tente novamente")
                 .NotNull().WithMessage("Campo descrição não informado, Tente novamente")
                 .MaximumLength(250).WithMessage("Tamanho maximo excedido de 250 caracteres, Tente novamente")
                 .MinimumLength(3).WithMessage("Tamanho mininomo são 3 caracteres, Tente novamente")
                 ;

        }
    }
}
