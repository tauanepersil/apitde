﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.models
{
    public class debitarEstoque
    {
        public string codigo { get; set; }

        public int qtde { get; set; }
    }
}
