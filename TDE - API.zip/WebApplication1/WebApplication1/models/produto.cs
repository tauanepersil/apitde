﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.models
{
    public class produto
    {
        public int codigo { get; set; }
        public string nome { get; set; }
        public float precoVenda { get; set; }
        public float precoCusto { get; set; }
        public DateTime dataCadastro { get; set; }
        public bool ativo { get; set; }
        public int estoque { get; set; }
        public string imagem { get; set; }
        public float alturaCM { get; set; }
        public float larguraCM { get; set; }
        public float profundidadeCM { get; set; }

        public DateTime? dataDesativacao { get; set; }
        public string motivoDesativacao { get; set; }
        public int IDcategoria { get; set; }
        public Categoria categoria { get; set; }





    }
}
