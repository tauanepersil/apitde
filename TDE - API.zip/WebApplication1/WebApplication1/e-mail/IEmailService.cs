﻿using Microsoft.VisualStudio.Web.CodeGeneration.Contracts.Messaging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication1.e_mail
{

        public interface IEmailService
        {
            Task Enviar(Mensagem mensagem);
        }
}
